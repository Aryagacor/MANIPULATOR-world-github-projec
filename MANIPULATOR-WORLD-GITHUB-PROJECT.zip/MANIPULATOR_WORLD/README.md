# MANIPULATOR WORLD — BY ARYA

Android APK starter project. The APK is built automatically with GitHub Actions.

## Build APK with GitHub
1. Create a new GitHub repository.
2. Upload the contents of this folder (including `.github/workflows/build-apk.yml`).
3. Open the repository's **Actions** tab.
4. Select **Build MANIPULATOR WORLD APK** and press **Run workflow**, or push to `main`.
5. When the run finishes, open its summary and download `MANIPULATOR-WORLD-debug-apk` under Artifacts.

## Included
- Preserved anime video login layout: purple LOGIN, red DAFTAR, registration, forgot-password screen.
- Registration automatically signs in; remembered session persists until logout.
- Passwords are PBKDF2-hashed before local storage.
- Chess anime dashboard background and supplied app profile image.
- Psychology learning library, learning path, Level 5 school-manipulation case studies reframed for recognition and self-protection.
- AI Jailbreak Lab prompt library for ChatGPT/Chyps, Gemini/Kairo, and DeepSeek/Chyps, plus local prompt analyzer.

## Important implementation limits
- Account storage and password reset are local to one installation/device. There is no cloud account sync or verified email recovery in this starter.
- AI Jailbreak Lab is a prompt library/analyzer, not a live AI connection. Live AI requires a server-side API integration; never embed a secret API key in the APK.
- The Android build is unsigned debug APK, suitable for testing. A release APK needs a signing key configured securely in GitHub Secrets.
