# MANIPULATOR WORLD | BY ARYA

Updated editable Capacitor source project.

## Included updates
- Uploaded login-intro video plays fullscreen with its original audio after a successful manual login.
- Dashboard opens automatically when the video ends.
- Dashboard entrance, button press, and card entrance animations.
- Notification/support panel and WhatsApp developer link.
- Settings page with update history, security information, customization preview, and logout.
- Existing account registration, local session, learning content, and AI Lab retained.

## Build APK using GitHub Actions
1. Upload/extract this project into your GitHub repository (the files inside this ZIP should be at repository root).
2. Commit and push to the `main` branch.
3. Open **Actions** in GitHub.
4. Select **Build MANIPULATOR WORLD** and run the workflow, or wait for the push-triggered build.
5. Download the `MANIPULATOR-WORLD-APK` artifact from the completed workflow.

Note: the APK is not prebuilt in this ZIP. GitHub Actions builds it. The intro video is bundled locally, so it does not need an internet connection.
