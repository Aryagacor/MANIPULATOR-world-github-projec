# MANIPULATOR WORLD | BY ARYA

Updated editable Capacitor source project.

## Included updates
- Uploaded login-intro video plays fullscreen with its original audio after a successful manual login.
- Dashboard opens automatically when the video ends.
- Dashboard entrance, button press, and card entrance animations.
- Notification/support panel and WhatsApp developer link.
- Settings page with update history, security information, customization preview, and logout.
- Existing account registration, local session, learning content, and AI Lab retained.

## Build APK using GitHub Actions
1. Upload/extract this project into your GitHub repository (the files inside this ZIP should be at repository root).
2. Commit and push to the `main` branch.
3. Open **Actions** in GitHub.
4. Select **Build MANIPULATOR WORLD** and run the workflow, or wait for the push-triggered build.
5. Download the `MANIPULATOR-WORLD-APK` artifact from the completed workflow.

Note: the APK is not prebuilt in this ZIP. GitHub Actions builds it. The intro video is bundled locally, so it does not need an internet connection.

## Level Unlock System (Level 1–10)
- Mode: sequential. Level 1 is available to every normal user.
- A normal user unlocks the next level only after marking every chapter in the previous level complete.
- Progress is stored separately per username on the device.
- Developer account: username `ADMIN`; the password is the one supplied by the project owner.
- The developer role can view all levels without completing previous levels.

Security note: this project currently uses client-side/localStorage accounts. The seeded admin password is stored as a PBKDF2 hash, not plaintext, but a client-side app cannot securely protect a privileged role from someone who can inspect or modify the APK. For production/public release, move authentication, role checks, and progress validation to a trusted backend.
